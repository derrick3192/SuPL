package scpsolver.problems;

public interface SolutionRenderable {

	public String getSolutionRepresentation(double x[]);
	
}
