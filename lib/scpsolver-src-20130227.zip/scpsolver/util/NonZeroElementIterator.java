package scpsolver.util;

import java.util.Iterator;

public interface NonZeroElementIterator extends Iterator<Double> {
	
	public int getActuali();
	public int getActualj();
	
	
}
